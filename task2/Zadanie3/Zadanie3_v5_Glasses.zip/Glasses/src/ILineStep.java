public interface ILineStep {
    IProductPart buildProductPart();
}
