public interface IProductPart  {
}
