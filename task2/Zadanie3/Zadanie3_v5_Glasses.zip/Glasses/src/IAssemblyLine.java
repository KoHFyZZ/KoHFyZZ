public interface IAssemblyLine {
    IProduct assembleProduct(IProduct product);
}
